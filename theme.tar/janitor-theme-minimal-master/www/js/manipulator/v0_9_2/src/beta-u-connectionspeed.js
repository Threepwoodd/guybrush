// testing speed test
Util.connectionSpeed = function() {
	
	// load image and calculate speed

	
	
}