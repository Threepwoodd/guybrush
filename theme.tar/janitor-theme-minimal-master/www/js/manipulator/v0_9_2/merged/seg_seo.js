/*
Manipulator v0.9.2-full Copyright 2017 http://manipulator.parentnode.dk
js-merged @ 2017-01-11 05:29:39
*/

/*seg_seo_include.js*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {};
	u.version = "0.9.2";
	u.bug = u.nodeId = u.exception = function() {};
	u.stats = new function() {this.pageView = function(){};this.event = function(){};}
}

