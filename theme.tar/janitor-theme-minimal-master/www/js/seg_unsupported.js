
/*seg_unsupported_include.js*/

/*i-unsupported.js*/
function unsupported() {
	document.body.innerHTML = '<h1 style="text-align: center; margin: 20% 15% 15%; font-family: Arial; color: #333333">Your browser is NOT supported. It is more outdated than steam-engines, typewriters and VHS tapes, so stop acting surprised.</h1>';
}
window.onload = unsupported;
