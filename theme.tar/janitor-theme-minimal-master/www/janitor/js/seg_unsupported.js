
/*seg_unsupported_include.js*/

/*seg_unsupported_include.js*/

/*i-unsupported.js*/
function unsupported() {
	document.body.innerHTML = '<h1 style="text-align: center; margin: 20% 15% 15%; font-family: Arial; color: #333333, font-size: 16px;">Sorry, your browser is not supported in Janitor yet<br /> - we are working on it!</p>';
}
window.onload = unsupported;


