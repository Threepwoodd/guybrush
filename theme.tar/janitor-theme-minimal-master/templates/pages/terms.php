<div class="scene front i:front" itemscope itemtype="http://schema.org/NewsArticle">

	<h1 itemprop="headline">Terms and conditions</h1>

	<ul class="info">
		<li class="published_at" itemprop="datePublished" content="2016-09-07">2016-09-07, 14:58</li>
		<li class="modified_at" itemprop="dateModified" content="2016-09-07"></li>
		<li class="author" itemprop="author">Martin Kæstel Nielsen</li>
		<li class="main_entity share" itemprop="mainEntityOfPage" content="<?= SITE_URL ?>/terms"></li>
		<li class="publisher" itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
			<ul class="publisher_info">
				<li class="name" itemprop="name" content="parentnode.dk"></li>
				<li class="logo" itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
					<span class="image_url" itemprop="url" content="<?= SITE_URL ?>/img/logo-large.png"></span>
					<span class="image_width" itemprop="width" content="720"></span>
					<span class="image_height" itemprop="height" content="405"></span>
				</li>
			</ul>
		</li>
		<li class="image_info" itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
			<span class="image_url" itemprop="url" content="<?= SITE_URL ?>/img/logo-large.png"></span>
			<span class="image_width" itemprop="width" content="720"></span>
			<span class="image_height" itemprop="height" content="405"></span>
		</li>
	</ul>

	<div class="articlebody" itemprop="articleBody">
		<h2>This is the terms page</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</p>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</p>
	</div>

</div>
